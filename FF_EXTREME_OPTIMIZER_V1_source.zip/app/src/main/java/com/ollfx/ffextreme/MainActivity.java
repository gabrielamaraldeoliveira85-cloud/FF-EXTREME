package com.ollfx.ffextreme;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    private static final String FF = "com.dts.freefireth";
    private static final String FFMAX = "com.dts.freefiremax";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(28, 34, 28, 24);
        root.setBackgroundColor(Color.rgb(16,21,29));
        TextView title = new TextView(this);
        title.setText("FF EXTREME OPTIMIZER V1");
        title.setTextColor(Color.rgb(99,230,190)); title.setTextSize(23);
        title.setGravity(Gravity.CENTER); title.setPadding(0,12,0,24);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("REDMI NOTE 13 • ANDROID 15\nPainel local de serviço");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,0,0,24);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("Serviço: parado");
        status.setTextColor(Color.WHITE); status.setTextSize(17);
        status.setGravity(Gravity.CENTER); status.setPadding(0,12,0,24);
        root.addView(status);

        addButton(root, "ATIVAR SERVIÇO", v -> startOptimizer());
        addButton(root, "PARAR SERVIÇO", v -> {
            stopService(new Intent(this, OptimizerService.class));
            status.setText("Serviço: parado");
        });
        addButton(root, "ABRIR FREE FIRE", v -> openGame());
        TextView note = new TextView(this);
        note.setText("\nO serviço mantém uma notificação ativa. Android/MIUI podem encerrar processos por economia de bateria. Este app não altera mira, hitbox, velocidade do personagem, memória ou arquivos do Free Fire.");
        note.setTextColor(Color.rgb(185,195,207)); note.setTextSize(13);
        note.setPadding(0,22,0,0); root.addView(note);
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        }
    }

    private void addButton(LinearLayout root, String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(listener);
        root.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }
    private void startOptimizer() {
        Intent i = new Intent(this, OptimizerService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Serviço: ativo (notificação persistente)");
    }
    private void openGame() {
        PackageManager pm = getPackageManager();
        Intent i = pm.getLaunchIntentForPackage(FF);
        if (i == null) i = pm.getLaunchIntentForPackage(FFMAX);
        if (i == null) {
            Toast.makeText(this, "Free Fire não encontrado neste aparelho.", Toast.LENGTH_LONG).show();
        } else startActivity(i);
    }
}
