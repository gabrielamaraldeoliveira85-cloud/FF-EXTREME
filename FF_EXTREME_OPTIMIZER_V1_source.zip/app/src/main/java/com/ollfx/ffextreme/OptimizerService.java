package com.ollfx.ffextreme;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.os.IBinder;

public class OptimizerService extends Service {
    private static final String CHANNEL = "ff_optimizer_status";
    private static final int NOTIFICATION_ID = 4101;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
            .setContentTitle("FF EXTREME OPTIMIZER")
            .setContentText("Serviço local ativo • sem modificar o Free Fire")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build();
        startForeground(NOTIFICATION_ID, n);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL, "Status do otimizador", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Notificação contínua enquanto o serviço estiver ativo.");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
