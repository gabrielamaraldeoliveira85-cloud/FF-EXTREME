# FF EXTREME OPTIMIZER V1

Projeto Android nativo (Java) para Android 8+ / alvo Android 15.

## O que esta versão faz
- Painel simples para iniciar/parar um serviço em primeiro plano.
- Notificação persistente enquanto o serviço estiver ativo.
- Atalho para abrir Free Fire ou Free Fire MAX, se instalado.
- Não injeta código, não lê/escreve memória do jogo e não altera arquivos/rede do jogo.

## Limitações importantes
Este é um painel de serviço, não um mecanismo de aumento garantido de FPS. Um serviço Android não consegue manter outro app permanentemente em execução nem alterar headtracking, hitbox ou velocidade interna do personagem. MIUI/Android podem limitar processos e o serviço pode precisar ser iniciado novamente pelo usuário. O serviço usa o tipo `specialUse`; a distribuição pela Play Store exige análise de elegibilidade e justificativa.

## Como gerar o APK
Abra a pasta no Android Studio (versão compatível com Android Gradle Plugin 8.7.3), aguarde a sincronização e selecione:
Build > Build Bundle(s) / APK(s) > Build APK(s).

O APK de depuração será gerado em:
`app/build/outputs/apk/debug/app-debug.apk`

## Instalação
Instale o APK gerado no Redmi Note 13. Abra o app e toque em ATIVAR SERVIÇO. Conceda permissão para notificações quando solicitado.

## Observação
Este ambiente de criação não possui Android SDK/Gradle instalados; portanto, foi possível entregar o projeto-fonte, mas não compilar nem verificar um APK aqui.
